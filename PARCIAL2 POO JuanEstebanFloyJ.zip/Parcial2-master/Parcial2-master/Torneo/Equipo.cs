using System;
using System.Collections.Generic;
using System.Linq;
using Excepciones.CustomExceptions;

namespace linq.Torneo
{
    public class Equipo
    {
        #region Properties  
        public int Goles { get; set; }
        public int Asistencias { get; set; }
        public int Faltas { get; set; }
        public int TarjetasAmarillas { get; set; }
        public int TarjetasRojas { get; set; }
        public Seleccion Seleccion { get; set; }
        public bool EsLocal { get; set; }
        public int Puntos;

        #endregion Properties

        #region Initialize
        public Equipo(Seleccion seleccion)
        {
            this.Seleccion = seleccion;
        }
        #endregion Initialize

        #region Methods
        public void ExpulsarJugador(string name)
        {
            try
            {
                Jugador jugadorExpulsado = Seleccion.Jugadores.First(j => j.Nombre == name);
                TarjetasRojas++;
                if(TarjetasRojas == 1){
                    Console.WriteLine("Ya tiene roja");
                    return;
                }
                int cantidadJugadores = 0;
                cantidadJugadores = Seleccion.Jugadores.Count;
                if (cantidadJugadores <=  6)
                {
                    LoseForWException ex = new LoseForWException(Seleccion.Nombre);
                    ex.NombreEquipo = Seleccion.Nombre;
                    throw ex;
                }
                Seleccion.Jugadores.Remove(jugadorExpulsado);
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("No existe ese jugador para expulsarlo del equipo " + Seleccion.Nombre);
            }
            
        }
        public void sacarAmarilla(string name){
            Jugador jugadorExpulsado2 = Seleccion.Jugadores.First(j => j.Nombre == name);
            TarjetasAmarillas++;
            if(TarjetasAmarillas >= 2){
                ExpulsarJugador(jugadorExpulsado2.Nombre);
                TarjetasRojas++;
            }
            else if(TarjetasAmarillas > 2){
                Console.WriteLine("No se puede tener mas de 2 tarjetas amarillas");
            }

        }

        public void sacarRoja(string name){
            Jugador jugadorExpulsado3 = Seleccion.Jugadores.First(j => j.Nombre == name);
            TarjetasRojas++;
            if(TarjetasRojas == 1){
                ExpulsarJugador(jugadorExpulsado3.Nombre);
            }
            else if(TarjetasRojas > 1){
                Console.WriteLine("no se puede tener mas de 1 tarjeta roja");
            }
            
        }
    #endregion Methods
    }
}